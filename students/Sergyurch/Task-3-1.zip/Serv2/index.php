<!DOCTYPE html>
<html>
	<head>
		<title>Урок №3. Практическое задание.</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	</head>
	<body>
		<header>
			<nav>
				<ul class="nav nav-pills" role="tablist">
					<li class="nav-item">
						<a class="nav-link" data-toggle="pill" href="main">Главная</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="pill" href="contacts">Контакты</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="pill" href="portfolio">Портфолио</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="pill" href="services">Услуги</a>
					</li>
				</ul>
		    </nav>
		</header>
				
		<?php
			$page = str_replace('/', '', $_SERVER[REQUEST_URI]);
								
			if ( file_exists('pages/'.$page.'.php') ) {
				include 'pages/'.$page.'.php';
			} else {
				include 'pages/main.php';
			}
		?>
		
		<footer>
			<h2>Footer</h2>
		</footer>
	</body>
</html>
