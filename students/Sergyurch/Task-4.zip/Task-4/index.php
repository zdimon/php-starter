<!DOCTYPE html>
<html>
	<head>
		<title>Урок №3. Шахматная доска</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="css/style.css" rel="stylesheet">
	</head>
	<body>
		<p>Есть такая строка 'one;two;three;four'</p><br>
		<p>Переформатируем ее в 3 варианта согласно заданию.</p><br>
		<p>Первый вариант: 
			<?php 
				$str = 'one;two;three;four';
				$arr = explode(';', $str);
				$new_arr = [];
			
				foreach ($arr as $elem) {
					array_push($new_arr, ucfirst($elem));
				}
			
				echo implode(';', $new_arr);
			?>
		</p>
		<p>Второй вариант: 
			<?php
				$new_arr = [];
								
				for ($i = 1; $i <= count($arr); $i++) {
					array_push($new_arr, $i.'-'.$arr[$i-1]);
				}
			
				echo implode(';', $new_arr);
			?>
		</p>
		<p>Третий вариант: 
			<?php
				$new_arr = array_reverse($arr);
				echo implode('-', $new_arr);
			?>
		</p>
	</body>
</html>
