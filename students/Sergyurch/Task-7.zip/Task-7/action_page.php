<!DOCTYPE html>
<html>
	<head>
		<title>Урок №7. Практическое задание.</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/style.css">
	</head>
	<body>
		<h1>Ответы:</h1>
		<?php
			$content = file_get_contents('quiz.json');
			$json_data = json_decode($content);
		
			foreach($json_data as $item) {
				if( array_key_exists($item->name, $_POST) ) {
					if( is_array($_POST[$item->name]) ) {
						echo $item->question. ' -- '. implode(', ', $_POST[$item->name]). '<br>';
					} else {
						echo $item->question. ' -- '. $_POST[$item->name]. '<br>';
					}
				} else {
					echo $item->question. ' -- Ответ не выбран<br>';
				}
			}
		?>
	</body>
</html>