<!DOCTYPE html>
<html>
	<head>
		<title>Урок №5</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/style.css" type="text/css">
	</head>
	<body>
		<form action="action_page.php" method="post">
			<label for="username">Имя пользователя:</label><br>
			<input type="text" id="username" name="username"><br>
			<label for="phone">Телефон:</label><br>
			<input type="tel" id="phone" name="phone"><br>
			<label for="address">Адрес:</label><br>
			<textarea id="address" name="address"></textarea><br>
			<input type="submit" value="Отправить">
		</form>
	</body>
</html>
