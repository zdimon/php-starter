<!DOCTYPE html>
<html>
	<head>
		<title>Урок №5</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/style.css" type="text/css">
	</head>
	<body>
		<p>Форма отправлена. Данные сохранены в файл.</p>
		<?php
			$username = $_POST['username'];
			$phone = $_POST['phone'];
			$address = $_POST['address'];
			file_put_contents("users/$phone.txt", $phone.';'.$username.';'.$address);
		?>
	</body>
</html>