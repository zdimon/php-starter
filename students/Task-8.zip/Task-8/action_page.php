<?php
	session_start();

	file_put_contents('results/results.json', json_encode($_POST));
	$_SESSION['message'] = 'Спасибо за то что приняли участие в викторине!';
	header('Location: /');
?>
