<h1>Викторина!!!</h1>

<?php
	$content = file_get_contents('quiz.json');
	$json_data = json_decode($content);
?>

<div class="questions">
	<form method="post" action="/action_page.php">
		<?php foreach($json_data as $item): ?>
			<h2><?php echo $item->question; ?></h2>

			<?php if( $item->type == 'text' ): ?>

				<input type="text" name="<?php echo $item->name ?>" placeholder="Введите ответ" required>

			<?php elseif( $item->type == 'select' ): ?>

				<select name="<?php echo $item->name ?>">
					<?php foreach($item->answers as $a): ?>
						<option value="<?php echo $a->is_valid ? 'true': 'false' ?>"><?php echo $a->text  ?></option>
					<?php endforeach ?>
				</select>

			<?php else: ?>

				<ul>
				<?php foreach($item->answers as $a): ?>
					<li>
						<?php if( $item->type == 'radio' ): ?>
							<input type="radio" value="<?php echo $a->is_valid ? 'true': 'false' ?>" name="<?php echo $item->name ?>" required>
						<?php endif ?>

						<?php if( $item->type == 'checkbox' ): ?>
							<input type="checkbox" name="<?php echo $item->name.'[]' ?>" value="<?php echo $a->text ?>">
						<?php endif ?>

						<?php echo $a->text ?>
					</li>
				<?php endforeach ?>
				</ul>

			<?php endif ?>

		<?php endforeach ?>
		<br>
		<br>
		<input type="submit" value="Отправить" />
	</form>
</div>
