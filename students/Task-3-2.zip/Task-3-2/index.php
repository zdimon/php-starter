<!DOCTYPE html>
<html>
	<head>
		<title>Урок №3. Шахматная доска</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/style.css">
	</head>
	<body>
		<div class="container">
			<?php
				$numbers = [1,2,3,4,5,6,7,8];
				$letters = ['a','b','c','d','e','f','g','h'];
				$color = 'white';
			
				foreach($numbers as $number) {
					foreach($letters as $letter) {
						echo '<div class="cell ' .$color .'">' .$number .$letter .'</div>';
						$color = change_color($color);
					}
					
					$color = change_color($color);
				}
				
				function change_color($color) {
					return ($color == 'white') ? 'black': 'white';
				}
			?>
		</div>
	</body>
</html>
