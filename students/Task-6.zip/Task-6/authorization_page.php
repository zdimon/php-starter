<?php
	session_start();

	if ( array_key_exists('username', $_POST) ) {
		if ( $_POST['username'] == 'admin' && $_POST['password'] == 'admin' ) {
			$_SESSION['username'] = 'admin';
			header('Location: /');
		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Страница авторизации</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/style_auth.css">
	</head>
	<body>
		<?php
			if ( array_key_exists('username', $_POST) || array_key_exists('password', $_POST) ) {
				echo '<p>Неправильный логин или пароль.</p>';
			}
		?>
		<form method="POST" action="/authorization_page.php">
			<label for="login">Логин</label><br>
			<input type="text" id="login" name="username"><br>
			<label for="password">Пароль</label><br>
			<input type="password" id="password" name="password"><br><br>
			<input type="submit" value="Войти">
		</form>
	</body>
</html>