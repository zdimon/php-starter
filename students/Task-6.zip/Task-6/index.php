<?php
	session_start();
	
	if ( !array_key_exists('username', $_SESSION) || $_SESSION['username'] != 'admin') {
		header('Location: /authorization_page.php');
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Урок №6. Практическое задание.</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	</head>
	<body>
		<header id="header">
			<nav>
				<ul class="nav nav-pills" role="tablist">
					<li class="nav-item">
						<a class="nav-link" data-toggle="pill" href="main">Главная</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="pill" href="contacts">Контакты</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="pill" href="portfolio">Портфолио</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="pill" href="services">Услуги</a>
					</li>
				</ul>
		    </nav>
			<div>
				<div>
					<?php echo 'Вы вошли как '.$_SESSION['username']; ?>
				</div>
				<a href="/logout.php" class="btn btn-info btn-block">Выйти</a>
			</div>
		</header>
				
		<?php
			$page = str_replace('/', '', $_SERVER['REQUEST_URI']);
								
			if ( file_exists('pages/'.$page.'.php') ) {
				include 'pages/'.$page.'.php';
			} else {
				include 'pages/main.php';
			}
		?>
		
		<footer>
			<h2>Footer</h2>
		</footer>
	</body>
</html>
